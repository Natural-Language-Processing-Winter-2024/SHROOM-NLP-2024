# Setup

- no Catboost classifier
- using NLI models (with all microsoft deberta models)
- using length features
- no task features
- no inverse NLI
- no OpenChat model
